#!/usr/bin/env python
# coding: utf-8

# # CUSTOMER CHURN PROJECT

# In[1]:


import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns


# In[2]:


df = pd.read_csv(r"C:\Users\Dell\Downloads\customer_churn (4).csv")
df


# In[3]:


pd.set_option("display.max_columns",None)


# In[4]:


df


# In[5]:


df.info()


# In[6]:


df.shape


# In[7]:


df.count()


# In[8]:


df.isnull().sum()


# In[9]:


df.duplicated().sum()


# # Tasks to be performed

# # Data Manipulation

# In[10]:


#● Extract the 5th column and store it in ‘customer_5’

customer_5 =df.iloc[:,4]
customer_5


# In[11]:


# ● Extract the 15th column and store it in ‘customer_15’

customer_15 = df.iloc[:,14]
customer_15


# In[12]:


# ● Extract all the male senior citizens whose payment method is electronic check and store the result in ‘senior_male_electronic’

filter = (df["gender"]=="Male") & (df["SeniorCitizen"]==1) &  (df["PaymentMethod"]=="Electronic check")
senior_male_electronic = df[filter]
senior_male_electronic


# In[13]:


# ● Extract all those customers whose tenure is greater than 70 months or their monthly charges is more than $100 and 
#store the result in ‘customer_total_tenure’

filter = (df["tenure"]>70) | (df['MonthlyCharges']>100)
customer_total_tenure = df[filter]
customer_total_tenure


# In[14]:


# ● Extract all the customers whose contract is of two years, payment method is mailed check and the value of churn is ‘Yes’ 
# and store the result in ‘two_mail_yes’

filter = (df["Contract"]=="Two year") & (df["PaymentMethod"]=="Mailed check") & (df["Churn"]=="Yes")
two_mail_yes = df[filter]
two_mail_yes


# In[15]:


# ● Extract 333 random records from the customer_churn dataframe and store the result in ‘customer_333’

customer_333 =df.sample(n=333)
customer_333


# In[16]:


# ● Get the count of different levels from the ‘Churn’ column

count=df['Churn'].value_counts()
count


# # Data Visualization:

# In[17]:


# ● Build a bar-plot for the ’InternetService’ column:
# a. Set x-axis label to ‘Categories of Internet Service’
# b. Set y-axis label to ‘Count of Categories’
# c. Set the title of plot to be ‘Distribution of Internet Service’
# d. Set the color of the bars to be ‘orange

fig = plt.figure(figsize=(5,5))
values_i=df['InternetService'].value_counts()
print(values_i)
plt.bar(values_i.index,values_i.values,color='orange')
plt.xlabel("Categories of Internet Service")
plt.ylabel("Count of Categories")
plt.title("Distribution of Internet Service")
plt.show()


# In[18]:


# ● Build a histogram for the ‘tenure’ column:
# a. Set the number of bins to be 30
# b. Set the color of the bins to be ‘green’
# c. Assign the title ‘Distribution of tenure'

tenure  = df['tenure']
plt.hist(tenure,color='green',bins=30)
plt.title("Distribution of tenure")
plt.show()


# In[19]:


# ● Build a scatter-plot between ‘MonthlyCharges’ and ‘tenure’. Map ‘MonthlyCharges’ to the y-axis and ‘tenure’ to the ‘x-axis’:
# a. Assign the points a color of ‘brown’
# b. Set the x-axis label to ‘Tenure of customer’
# c. Set the y-axis label to ‘Monthly Charges of customer’
# d. Set the title to ‘Tenure vs Monthly Charges’

sns.scatterplot(data = df,x = "tenure", y= "MonthlyCharges",color='brown')
plt.xlabel("Tenure of customer")
plt.ylabel("Monthly Charges of customer")
plt.title("Tenure vs Monthly Charges")
plt.show()


# In[20]:


# e. Build a box-plot between ‘tenure’ & ‘Contract’. Map ‘tenure’ on the y-axis & ‘Contract’ on the x-axis.

fig = plt.figure(figsize=(7,7))
sns.boxplot(data=df, x="Contract", y="tenure")
plt.xlabel("Contract")
plt.ylabel("Tenure")
plt.show()


# # Linear Regression

# In[21]:


# ● Build a simple linear model where dependent variable is ‘MonthlyCharges’
# and independent variable is ‘tenure’:
# a. Divide the dataset into train and test sets in 70:30 ratio.
# b. Build the model on train set and predict the values on test set
# c. After predicting the values, find the root mean square error
# d. Find out the error in prediction & store the result in ‘error’
# e. Find the root mean square error

from sklearn.linear_model import LinearRegression
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error


# In[22]:


x = df[['tenure']]
y = df['MonthlyCharges']


# In[23]:


x_train,x_test,y_train,y_test = train_test_split(x,y,test_size=0.3,random_state=1)


# In[24]:


lr = LinearRegression()


# In[25]:


lr.fit(x_train,y_train)


# In[26]:


y_pred = lr.predict(x_test)


# In[27]:


error= mean_squared_error(y_test,y_pred)
error


# In[28]:


RMSE = np.sqrt(error)
RMSE


# # Logistic Regression

# In[29]:


# ● Build a simple logistic regression model where dependent variable is
# ‘Churn’ and independent variable is ‘MonthlyCharges’:
# a. Divide the dataset in 65:35 ratio
# b. Build the model on train set and predict the values on test set
# c. Build the confusion matrix and get the accuracy score
# d. Build a multiple logistic regression model where dependent variable
# is ‘Churn’ and independent variables are ‘tenure’ and
# ‘MonthlyCharges’
# e. Divide the dataset in 80:20 ratio
# f. Build the model on train set and predict the values on test set
# g. Build the confusion matrix and get the accuracy score

from sklearn.linear_model import LogisticRegression
from sklearn.metrics import confusion_matrix,accuracy_score,classification_report


# In[30]:


x = df[['MonthlyCharges']]
y = df['Churn']


# In[31]:


x_train,x_test,y_train,y_test = train_test_split(x,y,test_size=0.35,random_state=1)


# In[32]:


logr = LogisticRegression()


# In[33]:


logr.fit(x_train,y_train)


# In[34]:


y_pred = logr.predict(x_test)
y_pred


# In[35]:


cm = confusion_matrix(y_test,y_pred)
plt.figure(figsize=(7,3))
sns.heatmap(cm,annot=True,cmap='Blues')
plt.xlabel("Predicted Data")
plt.ylabel("Actual Data")


# In[36]:


accuracy_score(y_test,y_pred)


# In[37]:


x = df[['tenure',"MonthlyCharges"]]
y = df['Churn']


# In[38]:


x_train,x_test,y_train,y_test = train_test_split(x,y,test_size=0.20,random_state=1)


# In[39]:


logreg = LogisticRegression()


# In[40]:


logreg.fit(x_train,y_train)


# In[41]:


y_pred = logreg.predict(x_test)
y_pred


# In[42]:


cm = confusion_matrix(y_test,y_pred)
plt.figure(figsize=(7,3))
sns.heatmap(cm,annot=True,cmap='Blues')
plt.xlabel("Predicted Data")
plt.ylabel("Actual Data")


# In[43]:


accuracy_score(y_test,y_pred)


# In[44]:


cr=classification_report(y_test,y_pred)
print(cr)


# # Decision Tree

# In[45]:


# ● Build a decision tree model where dependent variable is ‘Churn’ and
# independent variable is ‘tenure’:
# a. Divide the dataset in 80:20 ratio
# b. Build the model on train set and predict the values on test set
# c. Build the confusion matrix and calculate the accuracy

from sklearn.tree import DecisionTreeClassifier
from sklearn.metrics import accuracy_score,confusion_matrix,classification_report


# In[46]:


x = df[['tenure']]
y = df['Churn']


# In[47]:


x_train,x_test,y_train,y_test = train_test_split(x,y,test_size=0.20,random_state=1)


# In[48]:


depths = [1,2,3,4,5,6,7,8,9,10,100]
for x in depths:
    dt_model = DecisionTreeClassifier(max_depth=x,random_state=1)
    dt_model.fit(x_train,y_train)
    y_pred = dt_model.predict(x_test)
    acc = accuracy_score(y_test,y_pred)
    print("max_depth=",x,"accuracy_score=",acc)


# In[49]:


dt=DecisionTreeClassifier(max_depth=3,random_state=1)


# In[50]:


dt.fit(x_train,y_train)


# In[51]:


y_pred=dt.predict(x_test)
y_pred


# In[52]:


accrcy = accuracy_score(y_test,y_pred)
accrcy


# In[53]:


cm=confusion_matrix(y_test,y_pred)
cm


# In[54]:


cm = confusion_matrix(y_test,y_pred)
plt.figure(figsize=(7,3))
sns.heatmap(cm,annot=True,cmap='Blues')
plt.xlabel("Predicted Data")
plt.ylabel("Actual Data")


# In[55]:


cr=classification_report(y_test,y_pred)
print(cr)


# # Random Forest 

# In[56]:


# ● Build a Random Forest model where dependent variable is ‘Churn’ and
# independent variables are ‘tenure’ and ‘MonthlyCharges’:
# a. Divide the dataset in 70:30 ratio
# b. Build the model on train set and predict the values on test set
# c. Build the confusion matrix and calculate the accuracy

from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score,confusion_matrix,classification_report


# In[57]:


x = df[['tenure',"MonthlyCharges"]]
y = df['Churn']


# In[58]:


x_train,x_test,y_train,y_test = train_test_split(x,y,test_size=0.30,random_state=1)


# In[59]:


rf=RandomForestClassifier()


# In[60]:


rf.fit(x_train,y_train)


# In[61]:


y_pred=rf.predict(x_test)
y_pred


# In[62]:


accrcy=accuracy_score(y_test,y_pred)
accrcy


# In[63]:


cm=confusion_matrix(y_test,y_pred)
cm


# In[64]:


plt.figure(figsize=(7,3))
sns.heatmap(cm,annot=True,cmap='Blues')
plt.xlabel("Predicted Data")
plt.ylabel("Actual Data")


# In[65]:


cr=classification_report(y_test,y_pred)
print(cr)


# In[ ]:





# In[ ]:




